package int103w06w;

import collection.Group;
import human.Person;

public class Int103w06w {

    public static void main(String[] args) {
        testPerson();
        //testGroup();
        //testAssignment();
    }
    static void testAssignment() {
        //1.
        //2.
        //3.
    }
    static void testPerson() {
        var p0 = new Person("Bryan","Johnson");
        var p1 = new Person("Gina","Smith");
        var p2 = new Person("Bryan","Dole");
        var p3 = new Person("Gina","Johnson");
        var p4 = new Person("Bella","Dole");
        System.out.println("p0 : " + p0);
        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);
        System.out.println("p3 : " + p3);
        System.out.println("p4 : " + p4);
        var ps = new Person[] {p3, p4, p2, p0, p1};
        for (int i = 0; i < ps.length; i++) {
            System.out.printf("ps[%d]: %s%n", i, ps[i]);
        }
    }
    static void testGroup() {
        var p0 = new Person("Bryan","Johnson");
        var p1 = new Person("Gina","Smith");
        var p2 = new Person("Bryan","Dole");
        var p3 = new Person("Gina","Johnson");
        var p4 = new Person("Bella","Dole");
        var g = new Group<Person>();
        g.add(p3); g.add(p4); g.add(p2); g.add(p0); g.add(p1);
        System.out.println("Group<Person>: " + g);
    }
}
