package school;

import human.*;

public class Student extends Person {
    
    public Student(String firstname, String lastname) {
        super(firstname, lastname);
    }
    
    @Override 
    public String toString() {
        return super.toString();
    }
    
    
}
