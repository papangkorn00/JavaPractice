package int103w05w;

public class Int103w05w {

    public static void main(String[] args) {
    }
}
